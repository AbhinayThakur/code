/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.challenge.validation;

import com.challenge.util.AppException;
import com.challenge.util.SendMail;
import javax.ws.rs.core.Response;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author abhinay
 */
public class validate {
   
    public boolean  validatemail(String mailto, String sub, String msg) throws AppException{
        
        if(mailto.equals("")|| mailto==null){
        throw new AppException(Response.Status.BAD_REQUEST.getStatusCode(), 400, "Please provide mailTo params in REST",
                    "validate:validatemail");
        }else if(sub==null|| sub.equals("")){
            throw new AppException(Response.Status.BAD_REQUEST.getStatusCode(), 400, "Please provide proper Subject.",
                    "validate:validatemail");
        }else if(msg==null|| msg.equals("")){
            throw new AppException(Response.Status.BAD_REQUEST.getStatusCode(), 400, "Please provide proper mail body.",
                    "validate:validatemail");
        }
      
        SendMail sendMail=new SendMail();
        return sendMail.sendIt(mailto, sub, msg);
    }
    
}
