/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.challenge.codechallenge;

import com.challenge.util.AppException;
import com.challenge.validation.validate;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author abhinay
 */
@Path("sendmail")
public class sendMailRest {

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Response mail(@QueryParam("to") String mailto, @QueryParam("subject") String subject, @QueryParam("msg") String msg) throws AppException, JsonProcessingException {
        boolean result = new validate().validatemail(mailto, msg, msg);
      
            return Response.status(400).entity(result).type(MediaType.APPLICATION_JSON).build();


    }

}
