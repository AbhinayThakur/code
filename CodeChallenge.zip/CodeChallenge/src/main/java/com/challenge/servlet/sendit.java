package com.challenge.servlet;


import com.challenge.validation.validate;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@WebServlet("/sendit")
public class sendit extends HttpServlet {

    protected Log log = LogFactory.getLog(getClass());
    private static final long serialVersionUID = 1L;

    public sendit() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String to, sub, msg;
        to = request.getParameter("to");
        sub = request.getParameter("subject");
        msg= request.getParameter("msg");
        PrintWriter writer = response.getWriter();
        log.debug("inside sendit doPost()");
        log.info("to=" + to);
        log.info("msg=" + msg);

        try {
          
            validate obj= new validate();
           boolean result=obj.validatemail(to, sub, msg);
           
            log.info("password changed");
//            writer.println("success");
            writer.println("Mail Sent Successfully");

        } catch (Exception ex) {
            log.info(ex);

            writer.println("Something went wrong");
        }

        writer.close();
    }

}