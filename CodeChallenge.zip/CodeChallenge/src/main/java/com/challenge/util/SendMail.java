/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.challenge.util;

import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.ws.rs.core.Response;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 * @author abhinay
 */
public class SendMail {

    protected final Log log = LogFactory.getLog(getClass());

    String d_email = "abhinaythakur72@gmail.com";
    String d_password = "gameofme";
    String d_host = "smtp.gmail.com";
    String d_port = "465";

    public boolean sendIt(String m_to, String m_subject, String m_text) throws AppException {
        Properties props = new Properties();
        props.put("mail.smtp.user", d_email);
        props.put("mail.smtp.host", d_host);
        props.put("mail.smtp.port", d_port);
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.auth", "true");
//        props.put("mail.smtp.debug", "true");
        props.put("mail.smtp.socketFactory.port", d_port);
        props.put("mail.smtp.socketFactory.class",
                "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.socketFactory.fallback", "false");
        SecurityManager security = System.getSecurityManager();
        log.info("Security Check Sucess");
        try {

                             Authenticator auth = new SMTPAuthenticator();
                             Session session = Session.getInstance(props, auth);
         

                             MimeMessage msg = new MimeMessage(session);
                             msg.setContent(m_text, "text/html; charset=utf-8");
                             msg.setSubject(m_subject);
                             msg.setFrom(new InternetAddress(d_email));
                             log.info("Mail Sent Sucessfully");
                             msg.addRecipient(Message.RecipientType.TO,
                             new InternetAddress(m_to));
                             Transport.send(msg);
        } catch (Exception mex) {
            mex.printStackTrace();
            throw new AppException(Response.Status.BAD_REQUEST.getStatusCode(), 400, "Error : "+mex,
                    "validate:validatemail");
          
        }
        return true;
    }

    class SMTPAuthenticator extends javax.mail.Authenticator {

        public PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(d_email, d_password);
        }
    }
}
