/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.challenge.util;

import java.lang.reflect.InvocationTargetException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.glassfish.jersey.internal.Errors.ErrorMessage;
import org.springframework.beans.BeanUtils;


/**
 *
 * @author abhinay
 */
public class ErrorMsg {

    String message;

    int status;

    int code;


    String location;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
    
    
    
    public ErrorMsg(AppException ex){
       
        this.message = ex.getMessage();
        this.status = ex.getStatus();
        this.code = ex.getCode();
        this.location = ex.getLocation();
    }
    
    
}


