/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.challenge.util;

import java.io.Serializable;

/**
 *
 * @author abhinay
 *Exception class for throwing custom exceptions */
public class AppException extends Exception implements Serializable {

	
	int status;
	
	/** application specific error code */
	int code; 
		
		
	/** detailed error description for developers*/
	String location;	
	
	
	public AppException(int status, int code, String message,
			String location) {
		super(message);
		this.status = status;
		this.code = code;
		this.location = location;
		
	}

	public AppException() { }
        
	public String getMessage() {
		return super.getMessage();
	}

//	public void setMessage(String message) {
//		super.setMessage(message);
//	}
	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

}
